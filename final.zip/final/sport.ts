export class Sport { 
//sportsId:number;                                                                                                                                       sportId:number
sportName:string;
sportFees:string;
sportAddDate:Date;
adminName:string;
}
