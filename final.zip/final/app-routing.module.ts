import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminHomeComponent } from './admin/admin-home/admin-home.component'
import { LoginComponent } from './shared/login/login.component';
import { UserHomeComponent } from './user/user-home/user-home.component';
import { ManagerHomeComponent } from './manager/manager-home/manager-home.component';
import {AuthGuard} from './auth.guard'
import { RegisterComponent } from './shared/register/register.component';
import { HomeComponent } from './shared/home/home.component';
import { ListmanagersComponent } from './admin/listmanagers/listmanagers.component';
import { AddmanagerComponent } from './admin/addmanager/addmanager.component';
import { ViewEnrollmentsComponent } from './user/view-enrollments/view-enrollments.component';
import { SportListComponent } from './admin/sport-list/sport-list.component';
import { PendingEnrollmentsComponent } from './manager/pending-enrollments/pending-enrollments.component';
import { ApprovedEnrollmentsListComponent } from './manager/approved-enrollments-list/approved-enrollments-list.component';
import { RejectedEnrollmentsListComponent } from './manager/rejected-enrollments-list/rejected-enrollments-list.component';
import { AddsportComponent } from './admin/addsport/addsport.component';
import { UpdatesportComponent } from './admin/updatesport/updatesport.component';
import {UpdatepasswordComponent} from './admin/updatepassword/updatepassword.component';
const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: '', redirectTo:'home', pathMatch:'full'},
  {path: 'login', component: LoginComponent},   
  {path: 'login', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  {path:'addsport',component: AddsportComponent},
  {path:'adminhome', component: AdminHomeComponent,
     canActivate:[AuthGuard],
     data:{role: 'ROLE_ADMIN'}
    },
    {path:'listmanagers', component:ListmanagersComponent,
     canActivate:[AuthGuard],
     data:{role: 'ROLE_ADMIN'}
    },
    {path:'addmanager', component:AddmanagerComponent,
     canActivate:[AuthGuard],
     data:{role: 'ROLE_ADMIN'}
    },
    {
      path:'Sport-list',
      component: SportListComponent,
      canActivate:[AuthGuard],
     data: {role: 'ROLE_ADMIN'}
    } ,

    {
      path:'addsport',
      component:AddsportComponent,
      canActivate:[AuthGuard],
      data:{role:'ROLE_ADMIN'}
    },

   { path: 'update/:id',
    component:UpdatesportComponent,
    canActivate:[AuthGuard],
    data:{role:'ROLE_ADMIN'}

   },
 
   {
   path:'update-password',
   component:UpdatepasswordComponent,
   canActivate:[AuthGuard],
   data:{role:'ROLE_ADMIN'}
   },
 
    {path:'managerhome', component: ManagerHomeComponent,
    canActivate:[AuthGuard],
    data:{role: 'ROLE_MANAGER'}
   },
  {
    path: 'userhome',
    component: UserHomeComponent,
    canActivate:[AuthGuard],
    data: {role: 'ROLE_CUSTOMER'}
  },
  {
    path: 'viewuserenrollments',
    component: ViewEnrollmentsComponent,
    canActivate:[AuthGuard],
    data: {role: 'ROLE_CUSTOMER'}
  },
  {path:'pendingenrollments',
   component: PendingEnrollmentsComponent,
  canActivate:[AuthGuard],
  data:{role: 'ROLE_MANAGER'}
  },
  {path:'approvedenrollments',
   component: ApprovedEnrollmentsListComponent,
  canActivate:[AuthGuard],
  data:{role: 'ROLE_MANAGER'}
  },
  {path:'rejectedenrollments',
  component: RejectedEnrollmentsListComponent,
 canActivate:[AuthGuard],
 data:{role: 'ROLE_MANAGER'}
 }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
