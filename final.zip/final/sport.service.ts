import { Injectable } from '@angular/core';
import {  HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Sport } from 'src/app/models/sport';
import { environment } from 'src/environments/environment.prod';
import { Passwordupdate} from 'src/app/models/passwordupdate';
@Injectable({
  providedIn: 'root'
})
export class SportService {

   changepwd(pwd:Passwordupdate)
  {
    console.log(pwd);
    return this.http.post(environment.baseURL+"/admin/update-password",pwd,{responseType:'text'});

  }
  constructor(private http:HttpClient) { }
  getSports():Observable<any>{
    return this.http.get('http://localhost:8096/admin/list-sports')
  }
  registerSport(sport:Sport)
  {
    console.log(sport);
    return this.http.post(environment.baseURL+"/admin/add-sports",sport,{responseType:'text' as 'json'});

  }

  deleteSport(id: number): Observable<any> {
    return this.http.delete(environment.baseURL+"/admin/delete/"+id, { responseType: 'text' });
  }


  getSportById(id: number): Observable<any> {
    return this.http.get(environment.baseURL+"/admin/getsports/"+id);
  }

  updateSport(id: number, value: any): Observable<Object> {
    return this.http.put(environment.baseURL+"/admin/updatesports/"+id, value);
  }

  username: String
  ngOnInit() {
    this.username = sessionStorage.getItem('username')
  }
}