import { Component, OnInit } from '@angular/core';
import { Sport } from 'src/app/models/sport';
import { SportService } from 'src/app/shared/services/sport.service';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/authentication.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-addsport',
  templateUrl: './addsport.component.html',
  styleUrls: ['./addsport.component.css']
})
export class AddsportComponent implements OnInit {
  sport:Sport
   myDate=new Date()
   message=null;
  constructor(private sportService:SportService,
    private router:Router,
    private authenticateService: AuthenticationService

    ) {
    this.sport=new Sport();
   }
   

  ngOnInit(): void {
    this.sport.adminName=sessionStorage.getItem('username')
    this.sport.sportAddDate=this.myDate

  }

  onSubmit(){
    console.log(this.sport);
     this.sportService.registerSport(this.sport).subscribe(
       result=>{
         console.log(result);
            
         if(result)
         {
           this.message="Sport added successfully"
           alert(this.message);
           this.router.navigate(['Sport-list'])
         }       
       }   
     )
     console.log(this.sport);
   }

}
