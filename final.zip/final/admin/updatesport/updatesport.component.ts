import { Component, OnInit } from '@angular/core';
import { Sport } from 'src/app/models/sport';
import { Router, ActivatedRoute } from '@angular/router';
import { SportService } from 'src/app/shared/services/sport.service';
import { AuthenticationService } from 'src/app/authentication.service';


@Component({
  selector: 'app-updatesport',
  templateUrl: './updatesport.component.html',
  styleUrls: ['./updatesport.component.css']
})
export class UpdatesportComponent implements OnInit {


 id: number;
 
  sport:Sport;
  message=null;
  myDate=new Date()

  constructor(private route :ActivatedRoute ,private sportService:SportService,private router:Router,private authenticateService: AuthenticationService) { }

  ngOnInit(): void {
   
    this.id = this.route.snapshot.params['id'];
    
    this.sportService.getSportById(this.id)
      .subscribe(data => {
        console.log(data)
        this.sport = data;
        this.sport.adminName=sessionStorage.getItem('username')
        this.sport.sportAddDate=this.myDate
      }, error => console.log(error));
     
    }
    
      gotoList() {
        this.router.navigate(['Sport-list']);
      } 

      updateSport() {
        let observableResult = this.sportService.updateSport(this.id, this.sport);
        observableResult.subscribe(data => {
          console.log(data);
          this.message="Sport Updated successfully"
          alert(this.message);
           this.gotoList();
          }, error => console.log(error));
      }
    
      onSubmit() {
        this.updateSport();    
      }
          
  }


  








