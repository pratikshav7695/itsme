import { Component, OnInit } from '@angular/core';
import { Passwordupdate } from 'src/app/models/./passwordupdate';
import { Router } from '@angular/router';
import { SportService } from 'src/app/shared/services/sport.service';
import { AuthenticationService } from 'src/app/authentication.service';
@Component({
  selector: 'app-updatepassword',
  templateUrl: './updatepassword.component.html',
  styleUrls: ['./updatepassword.component.css']
})
export class UpdatepasswordComponent implements OnInit {

  pwd:Passwordupdate

  constructor(private sportService:SportService,
    private router:Router,
    private authenticateService: AuthenticationService) 
    {
      this.pwd=new Passwordupdate();
    }

  ngOnInit(): void {
  }

 onSubmit(){
    console.log(this.pwd);
     this.sportService.changepwd(this.pwd).subscribe(
       result=>{
         console.log(result);
         if(result)
         {
           this.authenticateService.logOut()
           this.router.navigate(['login'])
         }       
       }   
     )
 
     console.log(this.pwd);
     
      }

}
