import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { ListmanagersComponent } from './listmanagers/listmanagers.component';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from '../app-routing.module';
import { AddmanagerComponent } from './addmanager/addmanager.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { SportListComponent } from './sport-list/sport-list.component';
import { AddsportComponent } from './addsport/addsport.component';
import { UpdatesportComponent } from './updatesport/updatesport.component';
import {UpdatepasswordComponent}  from './updatepassword/updatepassword.component';
@NgModule({
  declarations: [AdminHomeComponent, ListmanagersComponent, AddmanagerComponent,SportListComponent, AddsportComponent,UpdatesportComponent,UpdatepasswordComponent],
  imports: [
    CommonModule, BrowserModule,
    AppRoutingModule,FormsModule,
    ReactiveFormsModule
    
  ],
  exports: [AdminHomeComponent,ListmanagersComponent, ReactiveFormsModule,SportListComponent,UpdatesportComponent,UpdatepasswordComponent]
  
})
export class AdminModule { }
