import { Component, OnInit } from '@angular/core';
import { from, Observable } from 'rxjs';
import { SportService } from 'src/app/shared/services/sport.service';
import { Sport } from 'src/app/models/sport';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sport-list',
  templateUrl: './sport-list.component.html',
  styleUrls: ['./sport-list.component.css']
})
export class SportListComponent implements OnInit {

  sports: Observable<Sport>
  message=null;
  
  constructor(private sportservice:SportService ,private router:Router) { }

  ngOnInit(): void {
  this.reloadData()
   } 
 

   reloadData() {
    this.sports = this.sportservice.getSports();
  }


   deleteSport(id: number) {
    this.sportservice.deleteSport(id)
      .subscribe(
        data => {
          console.log(data);           
          this.reloadData();      
        },
        error => console.log(error));
  }


  updateSport(id: number){
    this.router.navigate(['update', id]);
  }

  }
