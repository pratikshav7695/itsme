import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListmanagersComponent } from './listmanagers.component';

describe('ListmanagersComponent', () => {
  let component: ListmanagersComponent;
  let fixture: ComponentFixture<ListmanagersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListmanagersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListmanagersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
