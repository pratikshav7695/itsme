import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Users } from 'src/app/models/users';
import {UsersService} from '../../shared/services/users.service'

@Component({
  selector: 'app-listmanagers',
  templateUrl: './listmanagers.component.html',
  styleUrls: ['./listmanagers.component.css']
})
export class ListmanagersComponent implements OnInit {


   users: Observable<Users>
   constructor(private userService: UsersService) {
    
    }
 
   ngOnInit() {
    this.users = this.userService.getUsers()
   }

}

